package com.test.mapper;

import com.test.entity.Student;
import org.apache.ibatis.annotations.*;

import java.util.List;

public interface TestMapper {
    //里面就写我们在TestMapper.xml文件里面对应的方法
    @Insert("insert into student(sid,name,sex) values(#{sid},#{name},#{sex})")
    int insertStudent(@Param("sid") int sid, @Param("name") String name, @Param("sex") String sex);

    @Insert("insert into student(sid,name,sex) values(#{sid},#{name},#{sex})")
    int insertStudentByobject(Student student);

    @Select("select * from student where sid = #{sid}")
    Student selectStudent(int sid);

    @Select("select * from student")
    List<Student> selectStudentAll();

    @Delete("delete from student where sid = #{sid}")
    int deleteStudent(int sid);

    @Update("update student set sid = #{newsid}, name = #{newname}, sex = #{newsex} where sid = #{oldsid}")
    int updateStudent(@Param("oldsid") int oldsid, @Param("newsid") int newsid, @Param("newname") String name, @Param("newsex") String newsex);

}
