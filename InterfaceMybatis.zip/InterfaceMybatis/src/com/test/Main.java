package com.test;

import com.test.entity.Student;
import com.test.mapper.TestMapper;
import org.apache.ibatis.session.SqlSession;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        try(SqlSession session = MybatisUtil.getSqlSession(true);
            Scanner scanner = new Scanner(System.in)){
            TestMapper mapper = session.getMapper(TestMapper.class);

            while(true){
                System.out.println("=======================");
                System.out.println("欢迎使用学生信息管理系统");
                System.out.println("1.查看所有学生信息");
                System.out.println("2.查询学生信息");
                System.out.println("3.增加学生信息");
                System.out.println("4.删除学生信息");
                System.out.println("5.修改学生信息");
                System.out.println("6.退出");
                System.out.println("=======================");
                int choice = scanner.nextInt();
                switch (choice) {
                    case 1 -> {
                        mapper.selectStudentAll().forEach(System.out::println);
                    }
                    case 2 -> {
                        System.out.println("请输入学生的学号:");
                        int sid = scanner.nextInt();
                        System.out.println(mapper.selectStudent(sid));
                    }
                    case 3 -> {
                        System.out.println("输入学生学号:");
                        int sid = scanner.nextInt();//只有nextInt()会吃回车，要在调用一次nextLine();
                        scanner.nextLine(); // 清空输入缓冲区中的换行符
                        System.out.println("输入学生姓名:");
                        String name = scanner.nextLine();
                        System.out.println("输入学生性别:");
                        String sex = scanner.nextLine();
                        Student student = new Student().setSid(sid).setName(name).setSex(sex);
                        if (mapper.insertStudentByobject(student) == 1) {
                            System.out.println("插入成功!");
                        } else {
                            System.out.println("插入失败，请检查学号是否重复!");
                        }
                    }
                    case 4 -> {
                        System.out.println("请输入要删除的学号:");
                        int sid = scanner.nextInt();
                        if (mapper.deleteStudent(sid) == 1) {
                            System.out.println("删除成功!");
                        } else {
                            System.out.println("删除失败!");
                        }
                    }
                    case 5 -> {
                        System.out.println("请输入要修改的学生学号:");
                        int oldsid = scanner.nextInt();
                        scanner.nextLine();
                        System.out.println("请输入修改后的学号:");
                        int newsid = scanner.nextInt();
                        scanner.nextLine();
                        System.out.println("请输入修改后的姓名:");
                        String newname = scanner.nextLine();
                        System.out.println("请输入修改后的性别:");
                        String newsex = scanner.nextLine();
                        if (mapper.updateStudent(oldsid, newsid, newname, newsex) == 1) {
                            System.out.println("修改成功!");
                        } else {
                            System.out.println("修改失败!");
                        }
                    }
                    default -> {
                        System.out.println("正在退出程序...");
                        Thread.sleep(2000);
                        System.out.println("已退出,感谢您的使用!");
                        return;
                    }
                }
            }
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
    }
}
